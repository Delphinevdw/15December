package Logic;

import Database.DBConnector;
import Database.DBException;
import Database.DBTraveler;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

public class CreateInternalReport {

    //AANTAL TRAVELERS
    //AANTAL BOOKINGS
    //TRIPS BOOKED
    //MOST POPULAR AIRPORTS
    //TOTAL PRICE PER MONTH
    
    private ArrayList<Booking> bookings;
    private ArrayList<Ticket> tickets;
    private ArrayList<Reservation> reservations;
    private ArrayList<Flight> flights;
    private ArrayList<Traject> trajects;
    private ArrayList<Leg> legs;
  
    private static CreateInternalReport internalReport = new CreateInternalReport();

  public static CreateInternalReport getInstance() {
    return internalReport;
    }
  
  public CreateInternalReport() {
    try {
      bookings = Database.DBBooking.getBookings();
      tickets = Database.DBTicket.getTickets();
      reservations = Database.DBReservation.getReservations();
      flights = Database.DBFlight.getFlights();
      trajects = Database.DBTraject.getTrajects();
      legs = Database.DBLeg.getLegs();
    } 
    catch (DBException ex) {
      Logger.getLogger(CreateInternalReport.class.getName()).log(Level.SEVERE, null, ex);//houdt foutmeldingen bij
    }
  }

  public static int aantalTravelers(){
     int aantalTravelers = 0;
        Connection con = null;
        try {
          con = DBConnector.getConnection();
          Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
          String sql = "select COUNT(passport) AS aantalTravelers from db2019_13.travelers ";
          ResultSet count = stmt.executeQuery(sql);
          count.next();
          aantalTravelers = count.getInt("aantalTravelers");  
        } catch (SQLException | DBException ex) {
            Logger.getLogger(CreateInternalReport.class.getName()).log(Level.SEVERE, null, ex);
        }
        return aantalTravelers; 
    }
    
    public static int aantalBookings(){
     int aantalBookings = 0;
         Connection con = null;
        try {
          con = DBConnector.getConnection();
          Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
          String sql = "select COUNT(id) AS aantalBookings from db2019_13.bookings ";
          ResultSet count = stmt.executeQuery(sql);
          count.next();
          aantalBookings = count.getInt("aantalBookings");
        } catch (SQLException | DBException ex) {
            Logger.getLogger(CreateInternalReport.class.getName()).log(Level.SEVERE, null, ex);
        }
        return aantalBookings; 
    }
  
  //RETOURNEERT EEN MULTIARRAY MET 5 KOLOMMEN VAN ALLE BOOKINGS
  /*public String[][] findAllBookings() throws DBException{
      int lenght = -1;
      String[][] table = new String[200][5];
      
        for (Booking booking : bookings) {
            lenght = lenght + 1;
            int ticketIDi = booking.getTicketId();//juiste ticketID
            
            ArrayList<Reservation> orderedReservations = Database.DBReservation.getReservationsOrdered();
           
            //Zoek index van 1e juiste ticketID
            int indexTicketID1 = 0;
            for(int k = 0; k<orderedReservations.size(); k++){
                int ticketID1 = orderedReservations.get(k).getTicketID();//geselecteerd ticketID
                if(ticketIDi == ticketID1){
                    indexTicketID1 = k;
                    break;
                }
            }
      
            //Ga de reservations arraylist af vanaf de eerste juiste ticketID tot de laatste juiste ticketID
            //RETOURNEERT EEN ARRAY VAN ALLE VLUCHTEN DIE IN BOOKING i ZITTEN
            int i = indexTicketID1;
            int lenght2 = 0;
            int[] flightsInBooking = new int[10];
            while(ticketIDi == orderedReservations.get(i).getTicketID()){
                flightsInBooking[lenght2] = orderedReservations.get(i).getFlightID();
                lenght2 = lenght2 + 1;
                i++;
            }
            int[] flightsInBookingAdaptedLength = Arrays.copyOf(flightsInBooking, lenght2);

            //Origin en Destination ophalen
            int eenVluchtID = flightsInBooking[0];//juiste flightID
            //Zoek index van eenVluchtID
            int indexVlucht = 0;
            for(int k = 0; k<flights.size(); k++){
                int eenVluchtIDk = flights.get(k).getFlightnumber();//geselecteerd flightID
                if(eenVluchtID == eenVluchtIDk){
                    indexVlucht = k;
                    break;
                }
            }
            int trajectID = flights.get(indexVlucht).getTrajectID();//juiste trajectID
            //Zoek index van trajectID
            int indexTraject = 0;
            for(int k = 0; k<trajects.size(); k++){
                int trajectIDk = trajects.get(k).getId();//geselecteerd trajectID
                if(trajectID == trajectIDk){
                    indexTraject = k;
                    break;
                }
            }
            String origin = trajects.get(indexTraject).getOrigin();
            String destination = trajects.get(indexTraject).getDestination();
            
            //Totale prijs berekening
            double totalPrice = 0;//gaat die worden aangepast door de for loop?
            for(int k = 0; k<flightsInBookingAdaptedLength.length; k++){
                int flightIDk = flightsInBookingAdaptedLength[k];//juiste flightID
                //Zoek index van flightID
                int indexFlight = 0;
                for(int p = 0; p<flights.size(); p++){
                    int fligthIDp = flights.get(p).getFlightnumber();//geselecteerd flightID
                    if(flightIDk == fligthIDp){
                        indexFlight = p;
                        break;
                    }
                }
                double price = flights.get(indexFlight).getPriceperflight();
                totalPrice = totalPrice + price;
            } 
            String priceString = Double.toString(totalPrice);
            
             System.out.println(totalPrice);
            //Dep
            int flightID1 = 0; //gaat die worden aangepast door de for loop?
            for(int h = 0; h<flightsInBookingAdaptedLength.length; h++){
                int flightIDh = flightsInBookingAdaptedLength[h];//juiste flightID
                //Zoek index van flightIDh
                int indexFlight2 = 0;
                for(int p = 0; p<flights.size(); p++){
                    int fligthIDp = flights.get(p).getFlightnumber();//geselecteerd flightID
                    if(flightIDh == fligthIDp){
                        indexFlight2 = p;
                        break;
                    }
                }
                int trajectID2 = flights.get(indexFlight2).getTrajectID();//juiste trajectID
                //Zoek index van trajectID2
                int indexTraject2 = 0;
                for(int p = 0; p<trajects.size(); p++){
                    int trajectIDp = trajects.get(p).getId();//geselecteerd trajectID
                    if(trajectID2 == trajectIDp){
                        indexTraject2 = p;
                        break;
                    }
                }
                String originFlighth = trajects.get(indexTraject2).getOrigin();
                if(origin.equals(originFlighth)){
                    flightID1 = flightsInBookingAdaptedLength[h];
              }
            }
            
            //Zoek index van flightID1
                int indexFlightID1 = 0;
                for(int p = 0; p<flights.size(); p++){
                    int flightIDp = flights.get(p).getFlightnumber();//geselecteerd flightID
                    if(flightID1 == flightIDp){
                        indexFlightID1 = p;
                        break;
                    }
                }
            LocalDateTime dep = flights.get(indexFlightID1).getDeparture();
            DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
            String depString = dep.format(formatter);
            
            //Arr
            int flightIDlast = 0; //gaat die worden aangepast door de for loop?
            for(int h = 0; h<flightsInBookingAdaptedLength.length; h++){
                int flightIDh = flightsInBookingAdaptedLength[h];//juiste flightID
                //Zoek index van flightIDh
                int indexFlight2 = 0;
                for(int p = 0; p<flights.size(); p++){
                    int flightIDp = flights.get(p).getFlightnumber();//geselecteerd flightID
                    if(flightIDh == flightIDp){
                        indexFlight2 = p;
                        break;
                    }
                }
                int trajectID2 = flights.get(indexFlight2).getTrajectID();//juiste trajectID
                //Zoek index van trajectID2
                int indexTraject2 = 0;
                for(int p = 0; p<trajects.size(); p++){
                    int trajectIDp = trajects.get(p).getId();//geselecteerd trajectID
                    if(trajectID2 == trajectIDp){
                        indexTraject2 = p;
                        break;
                    }
                }
                String destinationFlighth = trajects.get(indexTraject2).getDestination();
                if(destination.equals(destinationFlighth)){
                    flightIDlast = flightsInBookingAdaptedLength[h];
              }
            }
            
            //Zoek index van flightIDlast
                int indexFlightIDlast = 0;
                for(int p = 0; p<flights.size(); p++){
                    int flightIDp = flights.get(p).getFlightnumber();//geselecteerd flightID
                    if(flightIDlast == flightIDp){
                        indexFlightIDlast = p;
                        break;
                    }
                }
            LocalDateTime arr = flights.get(indexFlightIDlast).getArrival();
            String arrString = arr.format(formatter);
            
            //Plaats opgehaalde gegevens in de multiarray
            table[lenght][1] = origin;
            table[lenght][2] = destination;
            table[lenght][3] = priceString;
            table[lenght][4] = depString;
            table[lenght][5] = arrString;
        }
      return table;
  }*/
    
      //RETOURNEERT EEN MULTIARRAY MET 5 KOLOMMEN VAN ALLE BOOKINGS
  public String[][] findAllBookings() throws DBException{
      int lenght = -1;
      String[][] table = new String[200][5];
      
        for (Booking booking : bookings) {
            lenght = lenght + 1;
            int ticketIDi = booking.getTicketId();//juiste ticketID
            
            ArrayList<Reservation> orderedReservations = Database.DBReservation.getReservationsOrdered();
           
            //Zoek index van 1e juiste ticketID
            int indexTicketID1 = 0;
            for(int k = 0; k<orderedReservations.size(); k++){
                int ticketID1 = orderedReservations.get(k).getTicketID();//geselecteerd ticketID
                if(ticketIDi == ticketID1){
                    indexTicketID1 = k;
                    break;
                }
            }
      
            //Ga de reservations arraylist af vanaf de eerste juiste ticketID tot de laatste juiste ticketID
            //RETOURNEERT EEN ARRAY VAN ALLE VLUCHTEN DIE IN BOOKING i ZITTEN
            int i = indexTicketID1;
            int lenght2 = 0;
            int[] flightsInBooking = new int[10];
            while(ticketIDi == orderedReservations.get(i).getTicketID()){
                flightsInBooking[lenght2] = orderedReservations.get(i).getFlightID();
                lenght2++;
                i++;
            }
            int[] flightsInBookingAdaptedLength = Arrays.copyOf(flightsInBooking, lenght2);
            
            //Origin en Destination ophalen
            int eenVluchtID = flightsInBooking[0];//juiste flightID
            //Zoek index van eenVluchtID
            int indexVlucht = 0;
            for(int k = 0; k<flights.size(); k++){
                int eenVluchtIDk = flights.get(k).getFlightnumber();//geselecteerd flightID
                if(eenVluchtID == eenVluchtIDk){
                    indexVlucht = k;
                    break;
                }
            }
            int trajectID = flights.get(indexVlucht).getTrajectID();//juiste trajectID
            //Zoek index van trajectID
            int indexTraject = 0;
            for(int k = 0; k<trajects.size(); k++){
                int trajectIDk = trajects.get(k).getId();//geselecteerd trajectID
                if(trajectID == trajectIDk){
                    indexTraject = k;
                    break;
                }
            }
            String origin = trajects.get(indexTraject).getOrigin();
            String destination = trajects.get(indexTraject).getDestination();
            
            //Totale prijs berekening
            double totalPrice = 0;
            for(int k = 0; k<flightsInBookingAdaptedLength.length; k++){
                int flightIDk = flightsInBookingAdaptedLength[k];//juiste flightID
                //Zoek index van flightIDk
                int indexFlight = 0;
                for(int p = 0; p<flights.size(); p++){
                    int fligthIDp = flights.get(p).getFlightnumber();//geselecteerd flightID
                    if(flightIDk == fligthIDp){
                        indexFlight = p;
                        break;
                    }
                }
                double price = flights.get(indexFlight).getPriceperflight();
                totalPrice = totalPrice + price;
            } 
            String priceString = Double.toString(totalPrice);
            
            //Dep
            int firstFlight = flightsInBookingAdaptedLength[0];//juiste flightID
            //Zoek index van flightIDh in flights
            int indexFirstFlight = 0;
            for(int p = 0; p<flights.size(); p++){
                int fligthIDp = flights.get(p).getFlightnumber();//geselecteerd flightID
                if(firstFlight == fligthIDp){
                    indexFirstFlight = p;
                    break;
                }
            }
            LocalDateTime dep = flights.get(indexFirstFlight).getDeparture();
            DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
            String depString = dep.format(formatter);
            
            //Arr
            int lastFlight = flightsInBookingAdaptedLength[lenght2];//juiste flightID
            //Zoek index van flightIDh in flights
            int indexLastFlight = 0;
            for(int p = 0; p<flights.size(); p++){
                int fligthIDp = flights.get(p).getFlightnumber();//geselecteerd flightID
                if(firstFlight == fligthIDp){
                    indexLastFlight = p;
                    break;
                }
            }
            LocalDateTime arr = flights.get(indexLastFlight).getArrival();
            String arrString = arr.format(formatter);
            
            //Plaats opgehaalde gegevens in de multiarray
            table[lenght][1] = origin;
            table[lenght][2] = destination;
            table[lenght][3] = priceString;
            table[lenght][4] = depString;
            table[lenght][5] = arrString;
        }
      return table;
  }

  
  //RETOURNEERT EEN ARRAY MET DAARIN ALLE LEGIDs PER TRAVELER
  public int[] findAllLegIDsTraveler(String passNum) throws DBException{
      ArrayList<Booking> gesorteerdeBookings = Database.DBBooking.getBookingsordered();

      //Zoek 1e juiste travelerID
      int indexTravelerID1 = 0;//gaat die worden aangepast door de for loop?
      for(int k = 0; k<gesorteerdeBookings.size(); k++){
          String travelerID = gesorteerdeBookings.get(k).getTravelerId();//geselecteerde passNum
          if(travelerID.equals(passNum)){
              indexTravelerID1 = k; //deze waarde wordt toch meegegeven aan de int indexTravelerID1 he?
              break; //ga ik dan uit de volledige for lus? Want als de eerste juiste travelerID gevonden is moet hij stoppen
          }
      }
      
      int lenght = 0;
      int[] ticketIDs = new int[lenght];
      int i = indexTravelerID1;
      
      //Ga de booking arraylist af vanaf de eerste juiste travelerID tot de laatste juiste travelerID en maakt een array van alle ticketIDs van de traveler
      while(passNum.equals(gesorteerdeBookings.get(i).getTravelerId())){
          int ticketID = gesorteerdeBookings.get(i).getTicketId();
          lenght = lenght + 1;
          ticketIDs[lenght] = ticketID;
          i++;
      }
      
      ArrayList<Reservation> gesorteerdeReservations = Database.DBReservation.getReservationsOrdered();
      int indexTicket1;
      int lenght2 = 0;    
      int[] flightIDs = new int[lenght2]; 

      //Gaat de array van ticketIDs 1 voor 1 af en maakt een nieuwe array met daarin alle flightIDs van de traveler
      for(int j = 0; j<ticketIDs.length; j++){
          int ticketIDj = ticketIDs[j];//juiste ticketID
          int indexTicketIDj1 = 0;//gaat die worden aangepast door de for loop?
          //Zoek 1e juiste ticketID
          for(int l = 0; l<gesorteerdeReservations.size(); l++){
              int ticketID = gesorteerdeReservations.get(l).getTicketID();//geselecteerde ticketID
              if(ticketID == ticketIDj){
                  indexTicketIDj1 = l;
                  break;//ga ik dan uit de volledige for lus van l? Want als de eerste juiste ticketID gevonden is moet hij stoppen
              }
          }
          
          while(ticketIDj == gesorteerdeReservations.get(indexTicketIDj1).getTicketID()){
              int flightID = gesorteerdeReservations.get(indexTicketIDj1).getFlightID();
              lenght = lenght + 1;
              flightIDs[lenght] = flightID;
              indexTicketIDj1++;
          }
      }
      
      int lenght3 = 0;
      int[] legIDs = new int[lenght3];
      
      //Gaat de array van flightIDs 1 voor 1 af en maakt een nieuwe array met daarin alle legIDs van de traveler
      for(int z = 0; z<flightIDs.length; z++){
          int flightIDz = flightIDs[z];//juiste flightID
          //Zoek index van flightIDz
          int indexFlight = 0;
          for(int p = 0; p<flights.size(); p++){
            int flightIDp = flights.get(p).getFlightnumber();//geselecteerd flightID
            if(flightIDp == flightIDz){
                indexFlight = p;
                break;
            }
          }
          int legIDz = flights.get(indexFlight).getLegID();
          lenght3 = lenght3 + 1;
          legIDs[lenght3] = legIDz;
      }
      
      return legIDs;
  }
  
  //MOST POPULAR AIRPORTS - RETOURNEERT EEN ARRAYLIST VAN STRINGS MET DAARIN DE 5 POPULAIRSTE AIRPORTS
  public ArrayList<String> findpopuAirports() throws DBException{
        ArrayList<String> airport = new ArrayList<>();
        ArrayList<Traveler> travelers = DBTraveler.getTravelers();
        HashMap<String, Integer> topAirport = new HashMap<>();
        ArrayList<String> bestAirport = new ArrayList<>();
        ArrayList<String> top5Airport = new ArrayList<>();
        
        //Voegt de origin en destination van alle legs van alle travelers toe aan de arraylist airport
        for(Traveler klant : travelers){ //Gaat dit nu heel de lus doen voor ALLE travelers??
            int[] legsKlant = findAllLegIDsTraveler(klant.getPassportnr());
            for(int i = 0; i<legsKlant.length; i++){
                int legIDi = legsKlant[i];//juiste legID
                //Zoek index van flightIDz
                int indexLegi = 0;
                for(int p = 0; p<legs.size(); p++){
                    int legIDp = legs.get(p).getId();//geselecteerd legID
                    if(legIDi == legIDp){
                        indexLegi = p;
                        break;
                    }
                }
                airport.add(legs.get(indexLegi).getOrigin());
                airport.add(legs.get(indexLegi).getDestination());
            }
        }
        
        //Telt 1 op bij de airport die hij tegenkomt in de arraylist "airport"
        for (String airp : airport) {
            Integer i = topAirport.get(airp);
            if (i == null)
                topAirport.put(airp, 1);
            else
                topAirport.put(airp, i + 1);
        }

        ArrayList<Integer> voorkomen = new ArrayList<>();
        for (String oc : topAirport.keySet()) {
            voorkomen.add(topAirport.get(oc));
        }
        
        //Sorteert de arraylist "voorkomen" van hoog naar laag
        Collections.sort(voorkomen, Collections.reverseOrder());

        //Retourneert een arraylist van de airports, met de beste bovenaan
        for (Integer voorkomen1 : voorkomen) {
            for (String air : topAirport.keySet()) {
                if (voorkomen1.equals(topAirport.get(air))) {
                    bestAirport.add(air);
                }
            }
        }

        int n = 1;
        while (n <= 5) {
            top5Airport.add(bestAirport.get(n - 1));
            n++;
        }
        return top5Airport;
  }
  
  //RETOURNEERT DE TOTALE PRIJS VAN DE BOOKINGS PER MAAND
  //ik denk dat de prijs niet juist wordt opgeteld: NOG NIET JUIST DUS!!!
  public double pricePerMonth(int month) throws DBException{
  ArrayList<Booking> allbookings = Database.DBBooking.getBookings();
  ArrayList<Reservation> allreservations = Database.DBReservation.getReservationsOrdered();
  ArrayList<Integer> flightsofBooking = new ArrayList<>();
  ArrayList<Flight> flightsofMonth = new ArrayList<>();
  double totalPrice = 0;

  for(Booking b : allbookings){
      int bookIDb = b.getBookingreference();//juiste bookingID
      //Zoek index van bookIDb
          int indexofB = 0;
          for(int p = 0; p<allbookings.size(); p++){
            int bookIDp = allbookings.get(p).getBookingreference();//geselecteerd bookingID
            if(bookIDp == bookIDb){
                indexofB = p;
                break;
            }
          }      
      int ticketID = bookings.get(indexofB).getTicketId();
      
      int indexTicketID1 = 0;
      for(int i = 0; i<allreservations.size(); i++){
          if(ticketID == allreservations.get(i).getTicketID()){
              indexTicketID1 = i;
              break;
          }
      }
      
      while(ticketID == allreservations.get(indexTicketID1).getTicketID()){
        int flightID = allreservations.get(indexTicketID1).getFlightID();
        flightsofBooking.add(flightID);        
        indexTicketID1++;
      }
      
      //Vult de arraylist flightsofMonth
      for(Integer flightsIDs : flightsofBooking){
          int flightid = flightsIDs;//juiste flightID
          //Zoek index van flightid
          int indexFlightID = 0;
          for(int p = 0; p<flights.size(); p++){
            int flightIDp = flights.get(p).getFlightnumber();//geselecteerd flightID
            if(flightid == flightIDp){
                indexFlightID = p;
                break;
            }
          }  
          Flight vlucht = flights.get(indexFlightID);
          int monthofFlight = vlucht.getDeparture().getMonthValue();
          
          if(month == monthofFlight){
              flightsofMonth.add(vlucht);
          }    
      }
      
      //Totalprice
      for(Flight flightsmonth : flightsofMonth){
          double price = flightsmonth.getPriceperflight();
          totalPrice = totalPrice + price;//Geeft dit een nieuwe waarde aan de totalPrice BUITEN de loop?
      }
    }
    return totalPrice;
  }
}
