/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

import Database.DBException;
import Database.DBTraveler;
import java.util.ArrayList;

/**
 *
 * @author delph
 */
public class CreateTravelerOverview {
    
    private static CreateTravelerOverview travelerOverview = new CreateTravelerOverview();
    
    public ArrayList<Traveler> getTravelersList() throws DBException{
        return DBTraveler.getTravelers(); //Will return an array of all travelers? In objects.    
  }
  
  public static CreateTravelerOverview getInstance() {
        return travelerOverview;
    }

  public void deleteTraveler(String passnum) throws DBException{        
        DBTraveler.deleteTraveler(passnum);
  }
}
