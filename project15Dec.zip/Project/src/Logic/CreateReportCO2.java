package Logic;

import Database.DBException;
import Database.DBReservation; 
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CreateReportCO2 {
    
    private ArrayList<Traveler> travelers;
    private ArrayList<Booking> bookings;
    private ArrayList<Ticket> tickets;
    private ArrayList<Reservation> reservations;
    private ArrayList<Traject> trajects;
    private ArrayList<Flight> flights;
    //private CreateReportCO2 createReportCO2 = new CreateReportCO2();
  
    
  public CreateReportCO2() {
    try {
      travelers = Database.DBTraveler.getTravelers();
      bookings = Database.DBBooking.getBookings();
      tickets = Database.DBTicket.getTickets();
      reservations = Database.DBReservation.getReservations();
      trajects = Database.DBTraject.getTrajects();
      flights = Database.DBFlight.getFlights();
      
    } 
    catch (DBException ex) {
      Logger.getLogger(CreateReportCO2.class.getName()).log(Level.SEVERE, null, ex);   //WAT DOET DIT??
    }
  }
  
  //RETOURNEERT 1 TRAVELER WAARVAN HET PASSNUM IS GEGEVEN
  public Traveler findTraveler(String passNum){
    String traveleri;
    for (int i = 0; i < travelers.size(); i++) {
        traveleri = travelers.get(i).getPassportnr();
        
        if(traveleri.equals(passNum)){
            return travelers.get(i);
        }
    }
        return null;
  }
  
  //RETOURNEERT EEN ARRAY VAN DE BOOKINGID's WAARVAN DE TRAVELERID IS GEGEVEN
  public int[] findBookingIDs(String passNum){
    String passnum;
    int lenght = 0;//Is het juist om dit op nul te zetten? Wordt aangepast door de lenght+1
    int[] BookingIDs = new int[100];
    
    for (int i = 0; i < bookings.size(); i++) {
        passnum = bookings.get(i).getTravelerId();
        //TODO: change === into equal.....
        if(passnum.equals(passNum)){
            BookingIDs[lenght] = bookings.get(i).getBookingreference();
            lenght = lenght+1;
        }
    }
        return Arrays.copyOf(BookingIDs, lenght);
    //return BookingIDs;
  }
  
  //RETOURNEERT EEN ARRAY VAN DE TICKETID's WAARVAN DE TRAVELERID IS GEGEVEN

    
  public int[] findTicketID(String passNum){
    int[] BookingIDs = findBookingIDs(passNum);
    int lenght = 0;
    int[] TicketIDs = new int[100];
    
    //ga door de array van alle bookingsIDs van de traveler
    for (int i = 0; i < BookingIDs.length; i++) {
        int bookingIDi = BookingIDs[i];
        
        //zoek de index van de bookingIDi in de tabel met bookings
        int index = 0;  
        for (int k = 0; k<bookings.size(); k++) {
            if(bookingIDi == bookings.get(k).getBookingreference()){
                index = k;
            }
        }        
        
        //zoek op deze index het ticketID en voeg toe aan de array TicketIDs
        TicketIDs[lenght] = bookings.get(index).getTicketId();
        lenght = lenght+1;
    }
    return Arrays.copyOf(TicketIDs, lenght);
  } 
  

  
  //RETOURNEERT EEN ARRAY VAN DE FLIGHTID's WAARVAN DE TRAVELERID IS GEGEVEN
  public int[] findFlightIDs(String passNum) throws DBException{
    int[] TicketIDs = findTicketID(passNum);
    int lenght = 0;
    int[] FlightIDs = new int[200];
    
    for (int i = 0; i < TicketIDs.length; i++) {
        int ticketIDi = TicketIDs[i];
        
        ArrayList<Reservation> orderedReservations = Database.DBReservation.getReservationsOrdered();
        
        //zoek de index van de 1e ticketID in de tabel met reservations
        int index = 0;  
        for (int k = 0; k<orderedReservations.size(); k++) {
            if(ticketIDi == orderedReservations.get(k).getTicketID()){
                index = k;
                break;//stopt de for loop hier dan?
            }
        }
        while(ticketIDi == orderedReservations.get(index).getTicketID()){
                FlightIDs[lenght] = orderedReservations.get(index).getFlightID(); //flightIDs[0] = 1 klopte 
                lenght = lenght+1;
                index++; //index wordt 1 hij zoekt op index 1 maar die rij bestaat niet: zoeken naar onbestaand ticket id 
                
                if(index >=orderedReservations.size())
                    break;
        }    
    }
    return Arrays.copyOf(FlightIDs, lenght);
  }

  
  //RESTOURNEERT DE ORGIGIN WAARVAN DE TRAJECTID IS GEGEVEN
  public String findorigin(int trajectId){
      int trajectID;
      for(int i = 0; i<trajects.size(); i++){
          trajectID = trajects.get(i).getId();
          
          if(trajectID == trajectId)
              return trajects.get(i).getOrigin();
      }
      return null;
  }
  
  //RESTOURNEERT DE DESTINATION WAARVAN DE TRAJECTID IS GEGEVEN
  public String finddestination(int trajectId){
      int trajectID;
      for(int i = 0; i<trajects.size(); i++){
          trajectID = trajects.get(i).getId();
          
          if(trajectID == trajectId)
              return trajects.get(i).getDestination();
      }
      return null;
  }  
  
  //RETOURNEERT EEN MULTI ARRAY VAN DE VLUCHTEN MET DAARBIJ HUN UITSTOOT, WAARVAN DE TRAVELERID IS GEGEVEN
  public String[][] findCO2(String passNum) throws DBException{
    int[] FlightIDs = findFlightIDs(passNum);
    int lenght = 0;//Is het juist om dit op nul te zetten? Wordt aangepast door de lenght+1
    String[][] table = new String[200][4];

    for (int i = 0; i < FlightIDs.length; i++) {
        int flightIDi = FlightIDs[i];
        
        int index = 0;
        for(int k = 0; k < flights.size(); k++){
            if(flightIDi == flights.get(k).getFlightnumber()){
                index = k;
                break;
            }
        }
        
        int flightid = flights.get(i).getFlightnumber();
        if(flightIDi == flightid){
            String flightidString = Integer.toString(flightid);
            int traject = flights.get(index).getTrajectID();
            String origin = findorigin(traject);
            String destination = finddestination(traject);
            int co2 = flights.get(index).getCo2();
            String co2String = Integer.toString(co2);
                
            table[i][0] = flightidString;
            table[i][1] = origin;
            table[i][2] = destination;
            table[i][3] = co2String;
        }    
    }
    return table;
   }
  
}