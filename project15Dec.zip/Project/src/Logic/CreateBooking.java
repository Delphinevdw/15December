package Logic;

import Database.DBException;
import java.sql.SQLException;
import java.sql.Time;
import java.time.Duration;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.time.LocalDateTime;
import java.util.Arrays;
import Logic.Flight;

public class CreateBooking {
    private ArrayList<Traject> trajects;
    private ArrayList<Leg> legs;
    private ArrayList<Flight> flights;
    
      
  public CreateBooking() {
    try {
      trajects = Database.DBTraject.getTrajects();
      legs = Database.DBLeg.getLegs();
      flights = Database.DBFlight.getFlights();
    } 
    catch (DBException ex) {
      Logger.getLogger(CreateBooking.class.getName()).log(Level.SEVERE, null, ex);//houdt foutmeldingen bij
    }
  }
   
  //RETOURNEERT HET TRAJECTID WAARVAN DE ORIGIN EN DESTINATION IS GEGEVEN
  public int findTrajectID(String origin, String destination){
        for (Traject traject : trajects) {
            String orgininTrajecti = traject.getOrigin();
            String destinationTrajecti = traject.getDestination();
            if (orgininTrajecti.equals(origin) && destinationTrajecti.equals(destination)) {
                return traject.getId();
            }
        }
    return 0;
  }
  
  //RETOURNEERT EEN ARRAY VAN DE LEGID's WAARVAN DE ORIGIN EN DESTINATION IS GEGEVEN
  public int[] findLegID(String origin, String destination){
    int trajectID = findTrajectID(origin, destination);//juiste trajectID
    int lenght = 0;
    int[] LegIDs = new int[1000];    
    for (Leg leg : legs) {
        int traject = leg.getTrajectID();//geselecteerde trajectID
        if (traject == trajectID) {
            LegIDs[lenght] = leg.getId();
            lenght = lenght+1;
        }
    }
    //Een kopie van de arraylist LegIDs, alleen van de eerste 'length' elementen    
    return Arrays.copyOf(LegIDs, lenght);
  }
  
  //De Leg tussen Brussel en Parijs (bijvoorbeeld) zal heel dikwijls in de database zitten, voor elk traject
  //Dezelfde leg kan dus een ander legID met een ander trajectID hebben
  //Alle legs die door bovenstaande methode teruggegeven worden (via hun legID) horen bij een en hetzelfde traject
    
  
  //RETOURNEERT EEN MATRIX VAN ARRAYLISTS MET DAARIN PER LIJN DE LEGIDs DIE SAMEN EEN ROUTE VORMEN
  //Zet meerdere mogelijke combinaties van legs in een juiste volgorde (BRU-AM, AM-LON, LON-TOKIO of BRU-PARIJS, PARIJS-NY, NY-TOKIO) 
  public ArrayList<ArrayList<Integer>> findRoutes(String origin, String destination){
    int[] legIDs = findLegID(origin, destination);
    ArrayList<ArrayList<Integer>> routes = new ArrayList<>(); //matrix van ArrayLists, zowel rijen als kolommen variabel
    int rij = -1;
    
    for (int i = 0; i < legIDs.length; i++){
        int legi = legIDs[i];//juiste legID

        //Zoekt de index van legi
        int index = 0;  
        for (int k = 0; k<legs.size(); k++) {
            if(legi == legs.get(k).getId()){
                index = k;
                break;
            }
        }
        
        //als de index gevonden is, dan worden alle gegevens bijgehouden in losse variabelen
        String originLeg = legs.get(index).getOrigin();
        String destinationLeg = legs.get(index).getDestination();

        if(originLeg.equals(origin)){
            rij++; //Duid aan op welke rij we zitten
            routes.add(new ArrayList<Integer>()); //nieuwe rij toegevoegd, deze rij kan opgevraagd worden via routes.get(rij)
            routes.get(rij).add(legs.get(index).getId()); //huidige rij wordt opgevraagd, aan deze rij wordt de id van de leg toegevoegd
        
            while(!destinationLeg.equals(destination)){		
                String nextOrigin = destinationLeg; 
                for (int j = 0; j < legIDs.length; j++){
                    int legj = legIDs[j];//juiste legID
                    //Zoekt de index van legj
                    int index2 = 0;  
                    for (int k = 0; k<legs.size(); k++) {
                        if(legj == legs.get(k).getId()){
                            index2 = k;
                            break;
                        }
                    }
                    originLeg = legs.get(index2).getOrigin();
                    destinationLeg = legs.get(index2).getDestination();
                    if(nextOrigin.equals(originLeg) && !destinationLeg.equals(origin) && !destination.equals(nextOrigin)){					
			routes.get(rij).add(legs.get(index2).getId()); //id van nieuwe leg wordt achteraan de rij toegevoegd
                    }
                }		
            }
        }             
    }
    return routes;    
  }
  
  //RETOURNEERT EEN MATRIX VAN ARRAYLISTS MET DAARIN PER LIJN DE VLUCHTEN DIE AANEENSLUITEN OM VAN ORIGIN NAAR DESTINATION TE GAAN
  //Kan max met 1 overstap!! Zou meer moeten zijn... + Queries van de geïmporteerde methodes juistetijdFlights en juistetijdFlights2 zijn nog NIET juist!!
  public ArrayList<ArrayList<Integer>> findFlights(String origin, String destination, LocalDateTime departure) throws DBException, SQLException{
    //Haalt de arrayList van arrayLists op met per lijn 1 mogelijke route
    ArrayList<ArrayList<Integer>> routes = findRoutes(origin, destination);

    //De arraylist die moet worden opgevuld met per lijn aaneensluitende vluchten
    ArrayList<ArrayList<Integer>> possibleflights = new ArrayList<>();

    //Haalt de arraylist van flights op, waarbij de departure 2 dagen voor en 2 dagen na de gegeven departure valt - gesorteerd naar oplopende LEGIDs
    ArrayList<Flight> juistetijdFlights = Database.DBFlight.getFlightsgivenDeparture(departure);

    int rij = -1;

    
    //Gaat alle routes 1 voor 1 af
    for(int j = 0; j<routes.size(); j++){
        //GAAT OVER 1e LEG VAN ROUTE j
        int indexrow = j;
        int indexcolumn = 0;
        int legID1 = routes.get(indexrow).get(indexcolumn);//juiste legID
        //Zoekt de index van de eerste legID1 in juistetijdFlights
        int indexLegID1 = 0;  
        for (int k = 0; k<juistetijdFlights.size(); k++) {
            if(legID1 == juistetijdFlights.get(k).getLegID()){
                indexLegID1 = k;
                break;
            }
        }
            
        //Gaat de juistetijdFlights af voor zolang het om het juiste legID gaat en zet de mogelijke flightsnummers in de eerste kolom van possibleflights
        while(legID1 == juistetijdFlights.get(indexLegID1).getLegID()){
            possibleflights.add(new ArrayList<Integer>()); //nieuwe rij toegevoegd
            rij++;
            possibleflights.get(rij).add(juistetijdFlights.get(indexLegID1).getFlightnumber());
            indexLegID1++;     
        }
        
        //GAAT OVER 2e LEG VAN ROUTE j
        indexcolumn++;//we zitten nu in de 2e kolom van de j'e rij
        int legID2 = routes.get(indexrow).get(indexcolumn);//juiste legID
        
        //Gaat de arraylist af van de possibleflights die we tot nu toe hebben (van leg 1)
        for(int p = 0; p<possibleflights.size(); p++){
            int indexrowPosFlights = p;
            int indexcolumnFlight1 = 0;
            int flightIDp = routes.get(indexrowPosFlights).get(indexcolumnFlight1);//Eerste flightID van rij p
            //Zoekt de index van de flightIDp in flights
            int indexflightIDp = 0;  
            for (int k = 0; k<flights.size(); k++) {
                if(legID2 == flights.get(k).getLegID()){
                    indexflightIDp = k;
                    break;
                }
            }
            LocalDateTime arrivalPreviousFlight = flights.get(indexflightIDp).getArrival();
            
            //Haalt de arraylist van flights op, waarbij de departure max 1 dag na de arrival van de voorgaande vlucht valt - gesorteerd naar oplopende LEGIDs
            ArrayList<Flight> juistetijdFlights2 = Database.DBFlight.getFlightsafterGivenArrival(arrivalPreviousFlight); 
            //Zoekt de index van de eerste legID2 in juistetijdFlights2
            int indexLegID2 = 0;  
            for (int k = 0; k<juistetijdFlights2.size(); k++) {
                if(legID1 == juistetijdFlights2.get(k).getLegID()){
                    indexLegID2 = k;
                    break;
                }
            }
            int rijBis = -1;
            //Gaat de juistetijdFlights2 en zet de mogelijke flightsnummers in de tweede kolom van possibleflights, ALS er meerdere vluchten volgen op de eerste, voeg nieuwe rij in
            while(legID2 == juistetijdFlights2.get(indexLegID2).getLegID()){
                //Als er nog geen vlucht is toegevoegd die volgt op de eerste, voeg ze dan toe aan die rij
                if(possibleflights.get(rijBis+1).size() == 1){
                    rijBis++;
                    possibleflights.get(rijBis).add(juistetijdFlights2.get(indexLegID2).getFlightnumber());
                    indexLegID2++;
                }
                //Als er al wel een vlucht is toegevoegd die volgt op de eerste, maak dan een nieuwe rij met als eerste vlucht dezelfde en als tweede vlucht die er volgt op de eerste
                else{
                    rijBis++;
                    possibleflights.add(new ArrayList<Integer>()); //nieuwe rij toegevoegd
                    possibleflights.get(rijBis).add(juistetijdFlights2.get(indexLegID2).getFlightnumber());
                    indexLegID2++;
                }
            }
        }
    }
    return possibleflights;
 }
  
 //RETOURNEERT EEN ARRAYLIST MET PER RIJ EEN STRING VAN DE ORIGIN EN DESTINATION VAN AANEENSLUITENDE LEGS (bv: BRU - AM, AM - NY, NY - TOKIO) 
 public ArrayList<String> findFlightNames(String origin, String destination, LocalDateTime departure) throws DBException, SQLException{
    //Haalt de arrayList op van de possible flights
    ArrayList<ArrayList<Integer>> posFlights = findFlights(origin, destination, departure);
    
    //Op te vullen arrayList, met namen van origin-destination per leg
    ArrayList<String> namesFlights = new ArrayList<>();
    
    String rowQ = "";
    
    for(int q = 0; q<posFlights.size(); q++){//row posFlights
        for(int r = 0; r<posFlights.get(q).size(); r++){//column posFlights
            int flightIDqr = posFlights.get(q).get(r);//juiste flightID
            //Zoekt de index van flightIDqr in flights
            int indexflight = 0;  
            for (int k = 0; k<flights.size(); k++) {
                if(flightIDqr == flights.get(k).getFlightnumber()){
                    indexflight = k;
                    break;
                }    
            }
            
            //Zoekt legID van de flightID
            int legIDqr = flights.get(indexflight).getLegID();//juiste legID
            //Zoekt de index van legIDqr in legs
            int indexleg = 0;  
            for (int k = 0; k<legs.size(); k++) {
                if(legIDqr == legs.get(k).getId()){
                    indexleg = k;
                    break;
                }    
            }
            
            //Zoekt origin en destination van legID
            String originqr = legs.get(indexleg).getOrigin();
            String destinationqr = legs.get(indexleg).getDestination();
            
            //Plakt origin en destination aan elkaar in een string
            String flightqr = origin + " - " + destination;
            rowQ = rowQ + " , " + flightqr;
        }
        namesFlights.add(rowQ);
    }
    return namesFlights;
 }
   

 //RETOURNEERT EEN ARRAYLIST MET PER RIJ EEN TOTALE PRIJS VAN DE VLUCHTEN UIT 1 LIJN AANEENSLUITENDE VLUCHTEN
 public ArrayList<Double> findTotalPrice(String origin, String destination, LocalDateTime departure) throws DBException, SQLException{
    //Haalt de arrayList op van de possible flights
    ArrayList<ArrayList<Integer>> posFlights = findFlights(origin, destination, departure);

    //Op te vullen arrayList, met prijzen waarvan de rijnummer overeenkomt met de vluchten van diezelfde rijnummer in possibeFLights
    ArrayList<Double> prices = new ArrayList<>();
    
    for(int q = 0; q<posFlights.size(); q++){//row posFlights
        double totalPriceRowq = 0;
        for(int r = 0; r<posFlights.get(q).size(); r++){//column posFlights
            int flight = posFlights.get(q).get(r);
            //Zoekt de index van flight in flights
            int indexflight = 0;  
            for (int k = 0; k<flights.size(); k++) {
                if(flight == flights.get(k).getFlightnumber()){
                    indexflight = k;
                    break;
                }
            }
            double priceFlight = flights.get(indexflight).getPriceperflight();
            totalPriceRowq = totalPriceRowq + priceFlight;
        }
        prices.add(totalPriceRowq);
    }
    return prices;
 }
 
//RETOURNEERT EEN ARRAYLIST MET PER RIJ EEN TOTALE DURATION VAN DE VLUCHTEN UIT 1 LIJN AANEENSLUITENDE VLUCHTEN
 public ArrayList<Duration> findTotalDuration(String origin, String destination, LocalDateTime departure) throws DBException, SQLException{
    //Haalt de arrayList op van de possible flights
    ArrayList<ArrayList<Integer>> posFlights = findFlights(origin, destination, departure);

    //Op te vullen arrayList, met durations waarvan de rijnummer overeenkomt met de vluchten van diezelfde rijnummer in possibeFLights
    ArrayList<Duration> durations = new ArrayList<>();
    
    for(int q = 0; q<posFlights.size(); q++){//row posFlights
        for(int r = 0; r<posFlights.get(q).size(); r++){//column posFlights
            int firstfligthOfRow = posFlights.get(q).get(0);//juiste flightID
            //Zoekt de index van de eerste flight van posflights (= flightID) in flights
            int indexfirstflight = 0;  
            for (int k = 0; k<flights.size(); k++) {
                if(firstfligthOfRow == flights.get(k).getFlightnumber()){
                    indexfirstflight = k;
                    break;
                }
            }
            LocalDateTime startDateTime = flights.get(indexfirstflight).getDeparture();
            
            int lengteRijqPosFlights = posFlights.get(q).size();
            int lastflightOfRow = posFlights.get(q).get(lengteRijqPosFlights - 1);//juiste flightID
            //Zoekt de index van de laatste flight van posflights (= flightID) in flights
            int indexlastflight = 0;  
            for (int k = 0; k<flights.size(); k++) {
                if(lastflightOfRow == flights.get(k).getFlightnumber()){
                    indexlastflight = k;
                    break;
                }
            }
            LocalDateTime endDateTime = flights.get(indexlastflight).getArrival();

            Duration durationFlight = Duration.between(startDateTime, endDateTime);
            durations.add(durationFlight);
        }
    }
    return durations;
 }

}

 
