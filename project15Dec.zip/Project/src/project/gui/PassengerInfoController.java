/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.gui;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import Logic.Traveler;
import java.time.LocalDate;
import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;


/**
 * FXML Controller class
 *
 * @author delph
 */
public class PassengerInfoController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private TextField txtFirstName;
    @FXML
    private TextField txtLastName;
    @FXML
    private DatePicker dateOfBirthPicker;
    @FXML
    private CheckBox CBMale;
    @FXML
    private CheckBox CBFemale;
    @FXML
    private CheckBox CBX;
    @FXML
    private TextField txtPassportNumber;
    @FXML
    private TextField txtNationality;
    @FXML
    private TextField txtEmail;
    @FXML
    private Button Submitbtn;
    @FXML
    private Label firstNamelbl;
    @FXML
    private Label lastNamelbl;
    @FXML
    private Label genderlbl;
    @FXML
    private Label datelbl;
    @FXML
    private Label passportlbl;
    @FXML
    private Label nationalitylbl;
    @FXML
    private Label emaillbl;

    @FXML
    private AnchorPane dataPane;
    private project.gui.NewFXMain main;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    public void genderMaleHandler() {
        if (CBMale.isSelected()) {
            CBFemale.setSelected(false);
            CBX.setSelected(false);
        }
    }

    @FXML
    public void genderFemaleHandler() {
        if (CBFemale.isSelected()) {
            CBMale.setSelected(false);
            CBX.setSelected(false);
        }
    }

    @FXML
    public void genderXHandler() {
        if (CBX.isSelected()) {
            CBFemale.setSelected(false);
            CBMale.setSelected(false);
        }
    }

    @FXML
    public void addTraveler(ActionEvent event) {
        //FormValidation

        boolean firstName = textFieldNotEmpty(txtFirstName, firstNamelbl, "Please fill out a first name.");
        boolean lastName = textFieldNotEmpty(txtLastName, lastNamelbl, "Please fill out a last name.");
        boolean passportnumberOk = textFieldNotEmpty(txtPassportNumber, passportlbl, "Please fill out a passport number.");

        if (passportnumberOk) {
            passportnumberOk = passportFormatCheck(txtPassportNumber, passportlbl, "You must enter a valid passportNumber in ###-#######-##.");
        }
        boolean nationalityempty = textFieldNotEmpty(txtNationality, nationalitylbl, "Please fill out your nationality.");
        boolean emailOK = textFieldNotEmpty(txtEmail, emaillbl, "Please fill out your email address.");

        if (emailOK) {
            emailOK = emailFormatCheck(txtEmail, emaillbl, "You must enter a valid emailAdress example@hotmail.be format.");
        }

        if (firstName && lastName && passportnumberOk && nationalityempty && emailOK) {
            String firstname = txtFirstName.getText();
            String lastname = txtLastName.getText();
            LocalDate dateofbirth = (LocalDate) dateOfBirthPicker.getValue();

            //moet omgezet worden naar een date
            String gender;
            boolean male = CBMale.isSelected();
            boolean female = CBFemale.isSelected();
            boolean x = CBX.isSelected();

            if (male = true) {
                gender = "m";
            }
            if (female = true) {
                gender = "v";
            } else {
                gender = "x";
            }

            String passportnr = txtPassportNumber.getText();
            String nationality = txtNationality.getText();
            String email = txtEmail.getText();

            Traveler traveler = new Traveler(passportnr, firstname, lastname, gender, nationality, email, dateofbirth);
            traveler.addTraveler();
            //JFrame  frame = new JFrame("example");
            //JOptionPane.showMessageDialog(frame, "Traveler is inserted/updated Succesfully");
            txtFirstName.clear();
            txtLastName.clear();
            txtPassportNumber.clear();
            txtNationality.clear();
            txtEmail.clear();
            
        }
    }

    public boolean textFieldNotEmpty(TextField i) {
        boolean notempty = false;
        if (i.getText() != null && !i.getText().isEmpty()) {
            notempty = true;
        }
        return notempty;
    }

    public boolean textFieldNotEmpty(TextField i, Label l, String sValidationText) {
        boolean r = true;
        String c = null;
        if (!textFieldNotEmpty(i)) {
            r = false;
            c = sValidationText;
        }
        l.setText(c);
        return r;
    }

    public boolean passportFormatCheck(TextField i, Label l, String sValidationText) {
        boolean r = true;
        String c = null;
        if (!i.getText().matches("\\d{3}-\\d{7}-\\d{2}")) {
            r = false;
            c = sValidationText;
        }
        l.setText(c);
        return r;
    }

    public boolean emailFormatCheck(TextField i, Label l, String sValidationText) {
        boolean r = true;
        String c = null;
        if (!i.getText().matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$")) {
            r = false;
            c = sValidationText;
        }
        l.setText(c);
        return r;
    }


}
