/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.gui;


import Database.DBException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import Logic.Booking;
import Logic.CreateBooking;
import java.sql.SQLException;
import java.sql.Time;
import javafx.scene.input.MouseEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.AnchorPane;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 * FXML Controller class
 *
 * @author delph
 */
public class FlightRequirementsController implements Initializable 
{

    /**
     * Initializes the controller class.
     */
    @FXML
    private TextField txtFrom;
    @FXML
    private TextField txtTo; 
    @FXML
    private TextField txtnumberOfTravelers;
    @FXML
    // EEN KNOP: BOOKING TOEVOEGEN AAN DE PERSOON
    // NIEUW BOOKING NUMMER DAN??? INSERT VAN BOOKING
    private TextField txtPassportnumber; 
    @FXML
    private Button searchBookingbtn; 
    @FXML
    private Button addTicketbtn; 
    private CheckBox CBDuration; 
    private CheckBox CBPrice; 
    private CheckBox CBCO2; 
    private CheckBox CBTransfers; 
    
    private Booking model;
    
    @FXML
    private AnchorPane flightPane;
    @FXML
    private DatePicker departure;
    //IDEE: EEN ENKELE TABLE EN TWEE KEER DE FORM INVULLEN
    //TWEEDE KEER STAAN DE AIRPORTCODES IN OMGEKEERDE VOLGORDE 
   
    
    // Niet tableView<Flight>, want de paden moeten gegeven worden
    // path= BRU-AMS-LAX : een string die aangemaakt moet worden  in klasse flightpath
    @FXML
    private TableView flightView;

    
    @FXML
    private AnchorPane dataPane;
    
    //flightView
    private TableColumn<String, String> pathColumn;
    @FXML
    private TableColumn<LocalDateTime, LocalDateTime> arrDateTimeColumn;
    @FXML
    private TableColumn<Integer,Integer > transfersColumn;
    @FXML
    private TableColumn<Integer, Integer> CO2Column;
    @FXML
    private TableColumn<Double, Double> priceColumn;
    @FXML
    private TableColumn<Time, Time> durationColumn;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        
    }    
    
    //gebeurt als op de knop search booking geklikt wordt
   
    @FXML 
    public void mainConcernCO2Handler() {
        if( CBCO2.isSelected()){
            CBDuration.setSelected(false);
            CBPrice.setSelected(false);
            CBTransfers.setSelected(false);
        }
    }
    
    @FXML 
    public void mainConcernDurationHandler() {
        if( CBDuration.isSelected()){
            CBCO2.setSelected(false);
            CBPrice.setSelected(false);
            CBTransfers.setSelected(false);
        }
    }
    
    @FXML 
    public void mainConcernPriceHandler() {
        if( CBPrice.isSelected()){
            CBDuration.setSelected(false);
            CBCO2.setSelected(false);
            CBTransfers.setSelected(false);
        }
    }
    
    @FXML 
    public void mainConcernTransfersHandler() {
        if( CBTransfers.isSelected()){
            CBDuration.setSelected(false);
            CBPrice.setSelected(false);
            CBCO2.setSelected(false);
        }
    }
    
    //private ObservableList<String> flights;
    @FXML
    private void SearchBooking(MouseEvent Mouseevent) throws SQLException, DBException
        
        {   
            String origin = txtFrom.getText();
            String destination = txtTo.getText();
           
            boolean duration = CBDuration.isSelected();
            boolean price = CBPrice.isSelected();
            boolean CO2 = CBCO2.isSelected();
            boolean transfers = CBTransfers.isSelected();
            
            LocalDate departureDate = (LocalDate)departure.getValue();
            LocalDateTime departureDateTime = departureDate.atStartOfDay();
            
            CreateBooking obj = new CreateBooking();
            
            //ArrayList<String> resultFindFlightNames = obj.findFlightNames(origin, destination, departureDateTime);
            
            ObservableList<String> flights;
            flights =  FXCollections.observableList(obj.findFlightNames(origin, destination, departureDateTime));
            flightView.setItems(flights);
            pathColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue()));
            
            /*
            createBooking = CreateBooking.getInstance();
            try {
                flights =  FXCollections.observableArrayList(CreateBooking.findFlightNames(origin, destination, departureDateTime));
            } catch (DBException ex) {
                Logger.getLogger(CustomerManagementController.class.getName()).log(Level.SEVERE, null, ex);
            }
            flightView.setItems(flights);
*/
                //cellData.
            
        }
    
    @FXML
    private void addTicket (MouseEvent Mouseevent){
    
    }
    
}
