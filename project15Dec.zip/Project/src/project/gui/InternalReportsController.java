/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.gui;

import Database.DBException;
import Logic.Booking;
import Logic.CreateInternalReport;
import java.net.URL;
import java.util.Arrays;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.util.Callback;
/**
 * FXML Controller class
 *
 * @author delph
 */
public class InternalReportsController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private ListView popularAirportsListView; 
    @FXML
    private TextField txtMonth; 
    @FXML
    private Button checkbtn; 
    @FXML
    private Button checkAirportsbtn;
    @FXML
    private Button checkTripsbtn;
    @FXML
    private ListView numberOfBookingsListView; 
    
    private AnchorPane dataPane; 
    
    //TripsBookedTable
    @FXML
    private TableColumn<Booking, String> priceColumn;

    @FXML
    private TableColumn<Booking, String> orginColumn;
        //Origin en destination van volledig traject dus en arr time is arr time van laatste vlucht
    @FXML
    private TableColumn<Booking, String> destinationColumn;
    
    @FXML
    private TableColumn<Booking, String> depDateTimeColumn;

    @FXML
    private TableColumn<Booking, String> arrDateTimeColumn;

    private CreateInternalReport internalReport;
    //private ObservableList<String> airports;
    //protected ListProperty<String> listProperty = new SimpleListProperty<>();
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {   /*
        //eerste: popular airports
        internalReport = CreateInternalReport.getInstance();
        try {
            airports =  FXCollections.observableArrayList(internalReport.findpopuAirports());
        } catch (DBException ex) {
            Logger.getLogger(InternalReportsController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //popularAirportsListView.setItems(airports);
        //popularAirportsListView.setCellValueFactory(cellData -> new SimpleStringProperty(cellData));
        
        popularAirportsListView.itemsProperty().bind(listProperty);
        listProperty.set(FXCollections.observableArrayList(airports));
        
        //tweede: alle bookingen        */
    }    
    
    
    @FXML
    private void CheckTripsBooked(MouseEvent Mouseevent)
    {
    try{
            internalReport = CreateInternalReport.getInstance();
            String[][] resultFindAllBookings = internalReport.findAllBookings();
            //dit resultaat 'report' is een 2D array
            StackPane root = new StackPane();

            ObservableList<String[]> data2 = FXCollections.observableArrayList();
            data2.addAll(Arrays.asList());
            TableView<String[]> tripsBookedTable = new TableView<>();
            for (int i = 0; i < resultFindAllBookings[0].length; i++) {
                TableColumn tc = new TableColumn(resultFindAllBookings[0][i]);
                final int colNo = i;
                tc.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<String[], String>, ObservableValue<String>>() {
                    @Override
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<String[], String> p) {
                        return new SimpleStringProperty((p.getValue()[colNo]));
                    }
                });
                tripsBookedTable.getColumns().add(tc);
            }
            tripsBookedTable.setItems(data2);
            root.getChildren().add(tripsBookedTable);

        } catch (DBException ex) {
                Logger.getLogger(InternalReportsController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
   /*
    action bij button moet terug
    
    @FXML
    private void CheckRevenuePerMonth(MouseEvent Mouseevent) 
    {
        //omzet: som prijs alle boekingen
    }*/
}
